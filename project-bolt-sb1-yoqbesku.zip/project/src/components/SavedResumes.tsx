import React, { useState } from 'react';
import { Save, Trash2, Eye, Edit3, Calendar, Star } from 'lucide-react';

interface SavedResume {
  id: number;
  name: string;
  text: string;
  score: number;
  date: string;
}

interface SavedResumesProps {
  savedResumes: SavedResume[];
  onLoad: (resume: SavedResume) => void;
  onDelete: (id: number) => void;
}

const SavedResumes: React.FC<SavedResumesProps> = ({ savedResumes, onLoad, onDelete }) => {
  const [confirmDelete, setConfirmDelete] = useState<number | null>(null);
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    });
  };
  
  const getScoreColor = (score: number) => {
    if (score >= 8) return 'text-green-600';
    if (score >= 6) return 'text-yellow-600';
    return 'text-red-600';
  };
  
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800">Saved Resumes</h2>
        <div className="text-sm text-gray-600">
          {savedResumes.length} {savedResumes.length === 1 ? 'resume' : 'resumes'} saved
        </div>
      </div>
      
      {savedResumes.length === 0 ? (
        <div className="bg-gray-50 border border-gray-200 rounded-lg p-8 text-center">
          <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
            <Save className="w-8 h-8 text-gray-500" />
          </div>
          <h3 className="text-lg font-medium text-gray-800 mb-2">No Saved Resumes</h3>
          <p className="text-gray-600 mb-4">
            Save your resumes to track your progress and keep different versions for different job applications.
          </p>
          <button 
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
            onClick={() => {}}
          >
            Create Your First Resume
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {savedResumes.map((resume) => (
            <div 
              key={resume.id} 
              className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition"
            >
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-lg font-medium text-gray-800">{resume.name}</h3>
                  <div className="flex items-center text-sm text-gray-500 mt-1">
                    <Calendar className="w-4 h-4 mr-1" />
                    <span>Saved on {formatDate(resume.date)}</span>
                  </div>
                </div>
                <div className="flex items-center">
                  <div className="flex items-center mr-4">
                    <Star className="w-4 h-4 mr-1 text-yellow-500" />
                    <span className={`font-medium ${getScoreColor(resume.score)}`}>
                      {resume.score.toFixed(1)}/10
                    </span>
                  </div>
                  <div className="flex space-x-1">
                    <button 
                      onClick={() => onLoad(resume)}
                      className="p-2 text-gray-600 hover:bg-gray-100 rounded-full transition"
                      title="Edit Resume"
                    >
                      <Edit3 className="w-5 h-5" />
                    </button>
                    <button 
                      onClick={() => setConfirmDelete(resume.id)}
                      className="p-2 text-gray-600 hover:bg-red-100 hover:text-red-600 rounded-full transition"
                      title="Delete Resume"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </div>
              
              <div className="mt-3">
                <div className="bg-gray-50 border border-gray-200 rounded p-3 max-h-24 overflow-hidden text-sm text-gray-700">
                  {resume.text.substring(0, 150)}
                  {resume.text.length > 150 && '...'}
                </div>
              </div>
              
              <div className="mt-3 flex justify-end">
                <button 
                  onClick={() => onLoad(resume)}
                  className="px-3 py-1.5 bg-blue-50 text-blue-600 rounded flex items-center text-sm hover:bg-blue-100 transition"
                >
                  <Eye className="w-4 h-4 mr-1.5" />
                  View & Edit
                </button>
              </div>
              
              {/* Delete Confirmation */}
              {confirmDelete === resume.id && (
                <div className="mt-3 bg-red-50 border border-red-200 rounded-lg p-3">
                  <p className="text-sm text-red-800 mb-2">
                    Are you sure you want to delete this resume? This action cannot be undone.
                  </p>
                  <div className="flex justify-end space-x-2">
                    <button 
                      onClick={() => setConfirmDelete(null)}
                      className="px-3 py-1 bg-gray-200 text-gray-800 rounded text-sm hover:bg-gray-300 transition"
                    >
                      Cancel
                    </button>
                    <button 
                      onClick={() => {
                        onDelete(resume.id);
                        setConfirmDelete(null);
                      }}
                      className="px-3 py-1 bg-red-600 text-white rounded text-sm hover:bg-red-700 transition"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
      
      <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h3 className="font-medium text-gray-800 mb-2">Resume Version Tips:</h3>
        <ul className="text-sm text-gray-700 space-y-2">
          <li className="flex items-start">
            <span className="text-blue-600 mr-2">•</span>
            <span>Create different versions of your resume for different job types or industries.</span>
          </li>
          <li className="flex items-start">
            <span className="text-blue-600 mr-2">•</span>
            <span>Save iterations as you improve your resume to track your progress over time.</span>
          </li>
          <li className="flex items-start">
            <span className="text-blue-600 mr-2">•</span>
            <span>Use descriptive names to easily identify each resume version (e.g., "Marketing Resume - Updated May 2025").</span>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default SavedResumes;