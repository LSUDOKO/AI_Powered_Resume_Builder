import React from 'react';
import { Save, BarChart2 } from 'lucide-react';

interface ResumeEditorProps {
  resumeText: string;
  setResumeText: (text: string) => void;
  currentResumeName: string;
  setCurrentResumeName: (name: string) => void;
  onAnalyze: () => void;
  onSave: () => void;
}

const ResumeEditor: React.FC<ResumeEditorProps> = ({ 
  resumeText, 
  setResumeText, 
  currentResumeName,
  setCurrentResumeName,
  onAnalyze,
  onSave
}) => {
  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold text-gray-800">Resume Editor</h2>
        <div className="flex space-x-2">
          <button 
            onClick={onSave}
            className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg flex items-center hover:bg-gray-200 transition"
            disabled={!resumeText.trim()}
          >
            <Save className="w-4 h-4 mr-2" />
            Save
          </button>
          <button 
            onClick={onAnalyze}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center hover:bg-blue-700 transition"
            disabled={!resumeText.trim()}
          >
            <BarChart2 className="w-4 h-4 mr-2" />
            Analyze
          </button>
        </div>
      </div>
      
      <div className="mb-4">
        <label htmlFor="resumeName" className="block text-sm font-medium text-gray-700 mb-1">
          Resume Name
        </label>
        <input
          type="text"
          id="resumeName"
          value={currentResumeName}
          onChange={(e) => setCurrentResumeName(e.target.value)}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          placeholder="Enter a name for your resume"
        />
      </div>
      
      <div className="border border-gray-300 rounded-lg overflow-hidden">
        <div className="bg-gray-100 px-4 py-2 border-b border-gray-300">
          <div className="flex items-center space-x-2">
            <span className="w-3 h-3 rounded-full bg-red-500"></span>
            <span className="w-3 h-3 rounded-full bg-yellow-500"></span>
            <span className="w-3 h-3 rounded-full bg-green-500"></span>
            <span className="ml-2 text-sm text-gray-600">Resume Content</span>
          </div>
        </div>
        <textarea
          value={resumeText}
          onChange={(e) => setResumeText(e.target.value)}
          className="w-full h-96 p-4 font-mono text-gray-800 focus:outline-none"
          placeholder="Paste or type your resume content here..."
        ></textarea>
      </div>
      
      <div className="mt-4 text-sm text-gray-600">
        <p>Tips:</p>
        <ul className="list-disc pl-5 mt-1 space-y-1">
          <li>Include your contact information, work experience, education, and skills.</li>
          <li>Use clear section headings to organize your resume.</li>
          <li>Quantify your achievements where possible (e.g., "Increased sales by 20%").</li>
          <li>For best results, add a job description in the Job Description tab for tailored feedback.</li>
        </ul>
      </div>
    </div>
  );
};

export default ResumeEditor;