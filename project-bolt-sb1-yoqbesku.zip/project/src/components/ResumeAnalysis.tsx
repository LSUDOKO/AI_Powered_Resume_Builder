import React from 'react';
import { ThumbsUp, ThumbsDown, Award, CheckCircle, AlertTriangle, Lightbulb } from 'lucide-react';

interface AnalysisProps {
  analysis: {
    score: number;
    strengths: string[];
    improvements: string[];
    suggestions: string;
    keywords?: string[];
  };
  onFeedback: (helpful: boolean) => void;
  feedbackGiven: boolean;
}

const ResumeAnalysis: React.FC<AnalysisProps> = ({ analysis, onFeedback, feedbackGiven }) => {
  const { score, strengths, improvements, suggestions, keywords } = analysis;
  
  // Determine score color based on value
  const getScoreColor = (score: number) => {
    if (score >= 8) return 'text-green-600';
    if (score >= 6) return 'text-yellow-600';
    return 'text-red-600';
  };
  
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800">AI Resume Analysis</h2>
        {!feedbackGiven ? (
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-600">Was this analysis helpful?</span>
            <button 
              onClick={() => onFeedback(true)}
              className="p-2 bg-gray-100 rounded-full hover:bg-green-100 transition"
              aria-label="Thumbs up"
            >
              <ThumbsUp className="w-5 h-5 text-gray-600" />
            </button>
            <button 
              onClick={() => onFeedback(false)}
              className="p-2 bg-gray-100 rounded-full hover:bg-red-100 transition"
              aria-label="Thumbs down"
            >
              <ThumbsDown className="w-5 h-5 text-gray-600" />
            </button>
          </div>
        ) : (
          <div className="text-sm text-green-600 flex items-center">
            <CheckCircle className="w-4 h-4 mr-1" />
            Thank you for your feedback!
          </div>
        )}
      </div>
      
      {/* Score Card */}
      <div className="bg-white border border-gray-200 rounded-xl shadow-sm p-6 mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Award className="w-10 h-10 text-blue-600 mr-3" />
            <div>
              <h3 className="text-lg font-semibold text-gray-800">Resume Score</h3>
              <p className="text-sm text-gray-600">Based on content, formatting, and relevance</p>
            </div>
          </div>
          <div className={`text-4xl font-bold ${getScoreColor(score)}`}>
            {score}/10
          </div>
        </div>
      </div>
      
      {/* Analysis Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        {/* Strengths */}
        <div className="bg-green-50 border border-green-200 rounded-xl p-6">
          <div className="flex items-center mb-4">
            <CheckCircle className="w-6 h-6 text-green-600 mr-2" />
            <h3 className="text-lg font-semibold text-gray-800">Strengths</h3>
          </div>
          <ul className="space-y-3">
            {strengths.map((strength, index) => (
              <li key={index} className="flex">
                <span className="text-green-600 mr-2">✓</span>
                <span className="text-gray-700">{strength}</span>
              </li>
            ))}
          </ul>
        </div>
        
        {/* Areas for Improvement */}
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-6">
          <div className="flex items-center mb-4">
            <AlertTriangle className="w-6 h-6 text-amber-600 mr-2" />
            <h3 className="text-lg font-semibold text-gray-800">Areas for Improvement</h3>
          </div>
          <ul className="space-y-3">
            {improvements.map((improvement, index) => (
              <li key={index} className="flex">
                <span className="text-amber-600 mr-2">!</span>
                <span className="text-gray-700">{improvement}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
      
      {/* Suggestions */}
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-6 mb-6">
        <div className="flex items-center mb-4">
          <Lightbulb className="w-6 h-6 text-blue-600 mr-2" />
          <h3 className="text-lg font-semibold text-gray-800">Suggestions for Improvement</h3>
        </div>
        <div className="bg-white border border-gray-200 rounded-lg p-4 font-mono text-sm whitespace-pre-wrap">
          {suggestions}
        </div>
      </div>
      
      {/* Keywords */}
      {keywords && keywords.length > 0 && (
        <div className="bg-indigo-50 border border-indigo-200 rounded-xl p-6">
          <div className="flex items-center mb-4">
            <div className="w-6 h-6 bg-indigo-600 rounded-full flex items-center justify-center text-white mr-2">
              #
            </div>
            <h3 className="text-lg font-semibold text-gray-800">Relevant Keywords</h3>
          </div>
          <div className="flex flex-wrap gap-2">
            {keywords.map((keyword, index) => (
              <span 
                key={index} 
                className="px-3 py-1 bg-indigo-100 text-indigo-800 rounded-full text-sm"
              >
                {keyword}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ResumeAnalysis;