import React from 'react';
import { FileText, Award } from 'lucide-react';

const Header = () => {
  return (
    <header className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white shadow-md">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <FileText className="h-8 w-8 mr-3" />
            <div>
              <h1 className="text-2xl font-bold">ResumeAI</h1>
              <p className="text-blue-100 text-sm">AI-Powered Resume Builder & Analyzer</p>
            </div>
          </div>
          
          <div className="hidden md:flex items-center space-x-1">
            <a href="#features" className="px-4 py-2 rounded hover:bg-blue-700 transition">Features</a>
            <a href="#templates" className="px-4 py-2 rounded hover:bg-blue-700 transition">Templates</a>
            <a href="#pricing" className="px-4 py-2 rounded hover:bg-blue-700 transition">Pricing</a>
            <a href="#faq" className="px-4 py-2 rounded hover:bg-blue-700 transition">FAQ</a>
          </div>
          
          <div>
            <button className="bg-white text-blue-600 px-4 py-2 rounded-lg font-medium hover:bg-blue-50 transition">
              Sign In
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;