import React from 'react';
import { FileText, Search, BarChart2 } from 'lucide-react';

interface JobDescriptionAnalyzerProps {
  jobDescription: string;
  setJobDescription: (text: string) => void;
  onAnalyze: () => void;
}

const JobDescriptionAnalyzer: React.FC<JobDescriptionAnalyzerProps> = ({ 
  jobDescription, 
  setJobDescription,
  onAnalyze
}) => {
  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold text-gray-800">Job Description Analyzer</h2>
        <button 
          onClick={onAnalyze}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center hover:bg-blue-700 transition"
          disabled={!jobDescription.trim()}
        >
          <BarChart2 className="w-4 h-4 mr-2" />
          Analyze Resume for This Job
        </button>
      </div>
      
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
        <div className="flex items-start">
          <Search className="w-5 h-5 text-blue-600 mt-0.5 mr-2 flex-shrink-0" />
          <p className="text-blue-800 text-sm">
            Paste a job description to get tailored resume recommendations. Our AI will analyze the job requirements and suggest improvements to make your resume more relevant for this specific position.
          </p>
        </div>
      </div>
      
      <div className="border border-gray-300 rounded-lg overflow-hidden">
        <div className="bg-gray-100 px-4 py-2 border-b border-gray-300 flex items-center">
          <FileText className="w-4 h-4 text-gray-600 mr-2" />
          <span className="text-sm text-gray-600">Job Description</span>
        </div>
        <textarea
          value={jobDescription}
          onChange={(e) => setJobDescription(e.target.value)}
          className="w-full h-80 p-4 font-mono text-gray-800 focus:outline-none"
          placeholder="Paste the job description here to get tailored resume recommendations..."
        ></textarea>
      </div>
      
      <div className="mt-6 space-y-4">
        <h3 className="text-lg font-semibold text-gray-800">How it works:</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 mb-3">1</div>
            <h4 className="font-medium text-gray-800 mb-2">Paste Job Description</h4>
            <p className="text-sm text-gray-600">Copy and paste the full job description from the job posting.</p>
          </div>
          
          <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 mb-3">2</div>
            <h4 className="font-medium text-gray-800 mb-2">AI Analysis</h4>
            <p className="text-sm text-gray-600">Our AI extracts key requirements, skills, and keywords from the job description.</p>
          </div>
          
          <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 mb-3">3</div>
            <h4 className="font-medium text-gray-800 mb-2">Tailored Recommendations</h4>
            <p className="text-sm text-gray-600">Get personalized suggestions to optimize your resume for this specific job.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobDescriptionAnalyzer;